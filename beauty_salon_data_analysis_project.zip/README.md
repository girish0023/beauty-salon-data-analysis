# Beauty Salon Customer Analysis

**Internship practice project — Week 1**  
Topic: Data Science Orientation & Problem Definition in Beauty & Wellness.

## Business problem
How can a beauty salon understand customer visit patterns and service revenue to improve customer retention and planning?

## Project contents
- `beauty_salon_analysis.py` — Python analysis using Pandas and Matplotlib.
- `sample_appointments.csv` — small synthetic dataset for practice.
- `Week1_Business_Problem_Report.docx` — problem definition and proposed analysis plan.

## How to run
1. Install Python.
2. Install the required packages:
   `pip install pandas matplotlib`
3. Run:
   `python beauty_salon_analysis.py`

The script prints appointment and revenue summaries, writes `service_summary.csv`, and saves `revenue_by_service.png`.

## Important note
The included records are synthetic sample data created for learning. They are not real salon records and must not be presented as actual business findings. For real analysis, use only authorised, anonymised data and document its source and limitations.
