"""
Beauty Salon Customer Analysis
Week 1 internship practice project.

This script uses a small sample dataset for learning purposes.
Replace it with authorised, anonymised real data before making business decisions.
"""

import pandas as pd
import matplotlib.pyplot as plt

data = {
    "customer_id": [101, 102, 103, 101, 104, 105, 102, 106, 103, 107, 101, 108],
    "visit_date": [
        "2026-01-05", "2026-01-06", "2026-01-08", "2026-01-20",
        "2026-01-22", "2026-02-02", "2026-02-07", "2026-02-12",
        "2026-02-15", "2026-02-18", "2026-02-25", "2026-02-28"
    ],
    "service": [
        "Haircut", "Facial", "Manicure", "Haircut", "Hair Coloring",
        "Facial", "Haircut", "Manicure", "Facial", "Hair Coloring",
        "Hair Coloring", "Haircut"
    ],
    "price_inr": [300, 900, 400, 300, 1500, 900, 300, 400, 900, 1500, 1500, 300],
    "appointment_status": [
        "Completed", "Completed", "Completed", "Completed", "Completed",
        "Cancelled", "Completed", "Completed", "Completed", "Completed",
        "Completed", "Completed"
    ]
}

df = pd.DataFrame(data)
df["visit_date"] = pd.to_datetime(df["visit_date"])

# Analyse completed appointments only for revenue and service popularity.
completed = df[df["appointment_status"] == "Completed"].copy()

print("BEAUTY SALON CUSTOMER ANALYSIS")
print("-" * 35)
print(f"Total appointments: {len(df)}")
print(f"Completed appointments: {len(completed)}")
print(f"Cancelled appointments: {(df['appointment_status'] == 'Cancelled').sum()}")
print(f"Completion rate: {len(completed) / len(df) * 100:.1f}%")
print(f"Revenue from completed appointments: ₹{completed['price_inr'].sum():,.0f}")
print(f"Unique customers: {df['customer_id'].nunique()}")

print("\nRevenue by service:")
print(completed.groupby("service")["price_inr"].sum().sort_values(ascending=False))

print("\nCompleted appointments by service:")
print(completed["service"].value_counts())

print("\nRepeat customers (2 or more completed visits):")
visits_per_customer = completed["customer_id"].value_counts()
print(visits_per_customer[visits_per_customer >= 2])

# Save summary tables.
completed.groupby("service").agg(
    appointments=("service", "count"),
    revenue_inr=("price_inr", "sum")
).sort_values("revenue_inr", ascending=False).to_csv("service_summary.csv")

# Create a simple chart.
revenue_by_service = completed.groupby("service")["price_inr"].sum().sort_values(ascending=False)
revenue_by_service.plot(kind="bar", title="Completed Appointment Revenue by Service")
plt.xlabel("Service")
plt.ylabel("Revenue (INR)")
plt.tight_layout()
plt.savefig("revenue_by_service.png")
print("\nSaved service_summary.csv and revenue_by_service.png")
print("Note: This is sample data for practice, not real salon business data.")
